// Função para enviar código para o ChatGPT via backend
document.getElementById('submitButton').addEventListener('click', async function() {
    const linguagem = document.getElementById('languageSelector').value;
    const codigo = editor.getValue();

    try {
        const response = await fetch('http://localhost:3000/enviar-codigo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ codigo, linguagem })
        });

        const data = await response.json();
        document.getElementById('output').textContent = data.resultado; // Certifique-se de que 'resultado' é a chave correta.
    } catch (error) {
        document.getElementById('output').textContent = 'Erro ao enviar código para correção.';
    }
});
