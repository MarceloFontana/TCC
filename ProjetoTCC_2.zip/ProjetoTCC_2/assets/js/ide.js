let editor;

        // Códigos "Hello, World!" para cada linguagem
        const helloWorldCodes = {
            javascript: `console.log('Hello, World!');`,
            python: `print("Hello, World!")`,
            java: `
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
            `,
            cpp: `
#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
            `,
            csharp: `
using System;

class Program {
    static void Main() {
        Console.WriteLine("Hello, World!");
    }
}
            `,
            c: `
#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}
            `
        };

        // Inicializar o Monaco Editor com uma linguagem padrão (JavaScript)
        require.config({ paths: { 'vs': 'https://unpkg.com/monaco-editor@0.33.0/min/vs' }});
        require(['vs/editor/editor.main'], function() {
            editor = monaco.editor.create(document.getElementById('container'), {
                value: helloWorldCodes.javascript,  // Inicializa com o "Hello, World!" em JavaScript
                language: 'javascript',  // Linguagem padrão
                theme: 'vs-dark'
            });
        });

        // Mudar a linguagem do editor e o código "Hello, World!" baseado na seleção do usuário
        document.getElementById('languageSelector').addEventListener('change', function() {
            const language = this.value;  // Obter a linguagem selecionada
            const helloWorldCode = helloWorldCodes[language];  // Obter o código "Hello, World!" para a linguagem
            monaco.editor.setModelLanguage(editor.getModel(), language);  // Alterar a linguagem do editor
            editor.setValue(helloWorldCode);  // Atualizar o conteúdo do editor com o código "Hello, World!"
        });

        // Função para executar código JavaScript e mostrar o output
            document.getElementById('runButton').addEventListener('click', function() {
                const language = document.getElementById('languageSelector').value;
                const code = editor.getValue();
    
                if (language === 'javascript') {
                    try {
                        const output = eval(code);  // Executar o código JS
                        document.getElementById('output').textContent = output || 'Código executado com sucesso!';
                    }
                    catch (error) {
                        console.error('Erro ao realizar a requisição:', error);
                        document.getElementById('output').textContent = 'Erro ao enviar código para correção. Verifique o console para mais detalhes.';
                    }
                } 
                
                else {
                    document.getElementById('output').textContent = 'A execução de outras linguagens não está suportada no navegador.';
                }
            });