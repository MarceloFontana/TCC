
const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();  // Carrega as variáveis de ambiente do arquivo .env

const app = express();
const port = 3000;

// Middleware para permitir requisições CORS e parsear JSON
app.use(cors());
app.use(express.json());

// Rota para enviar código para a API do ChatGPT
app.post('/enviar-codigo', async (req, res) => {
    const { codigo, linguagem } = req.body;
    const basePrompt = `Aqui está um código na linguagem ${linguagem}: \n${codigo}\nAvalie o código, diga o que pode ser melhorado, comente sobre a qualidade do código e forneça uma porcentagem de quão correto ele está.`;

    try {
        const response = await axios.post('https://api.openai.com/v1/completions', {
            model: "text-davinci-003",
            prompt: basePrompt,
            max_tokens: 500,
            temperature: 0.5
        }, {
            headers: {
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        res.json({ resultado: response.data.choices[0].text });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Erro ao chamar a API do ChatGPT' });
    }
});
    